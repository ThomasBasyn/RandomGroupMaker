﻿namespace RandomGroupGenerator
{
    partial class Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.llblPatrion = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(583, 75);
            this.label1.TabIndex = 0;
            this.label1.Text = "Made by Thomas Basyn\r\nfor more info pleas contact me at thomas.basyn@gmail.com\r\ni" +
    "f you want to support me you can on \r\n";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // llblPatrion
            // 
            this.llblPatrion.AutoSize = true;
            this.llblPatrion.Location = new System.Drawing.Point(388, 88);
            this.llblPatrion.Name = "llblPatrion";
            this.llblPatrion.Size = new System.Drawing.Size(80, 25);
            this.llblPatrion.TabIndex = 1;
            this.llblPatrion.TabStop = true;
            this.llblPatrion.Text = "Patrion";
            this.llblPatrion.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblPatrion_LinkClicked);
            // 
            // Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 176);
            this.Controls.Add(this.llblPatrion);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Info";
            this.Text = "Info";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel llblPatrion;
    }
}