﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomGroupGenerator
{
    public partial class frmGroups : Form
    {
        public frmGroups()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            txtUitvoer.Text = "";
            string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "klassen");
            string fileName = txtFileName.Text;
            string filePath = Path.Combine(folderPath, fileName);

            if (!File.Exists(filePath))
            {
                txtUitvoer.Text = "ERROR";
            }
            else
            {
                // Read names from the file
                string inputNames;
                using (StreamReader reader = new StreamReader(filePath))
                {
                    inputNames = reader.ReadLine();
                }

                // Split the input names into an array
                string[] names = inputNames.Split(' ');

                if (rbtNumber.Checked == true)
                {
                    int numGroups = Convert.ToInt32(nudNumber.Value);
                    if (numGroups <= 0)
                    {
                        txtUitvoer.Text = "Please enter a valid number of groups greater than 0.";
                    }
                    else
                    {
                        // Shuffle the names array randomly
                        Random random = new Random();
                        names = names.OrderBy(x => random.Next()).ToArray();

                        // Calculate the number of names per group and the remaining names
                        int namesPerGroup = names.Length / numGroups;
                        int remainingNames = names.Length % numGroups;

                        // Divide the shuffled names into groups
                        string[][] groups = new string[numGroups][];
                        int currentIndex = 0;

                        for (int i = 0; i < numGroups; i++)
                        {
                            // Determine the size of the current group
                            int currentGroupSize = namesPerGroup + (i < remainingNames ? 1 : 0);

                            // Take a portion of names for each group
                            groups[i] = names.Skip(currentIndex).Take(currentGroupSize).ToArray();

                            // Update the current index for the next iteration
                            currentIndex += currentGroupSize;
                        }

                        // Display the groups
                        txtUitvoer.Text += ("\nGroups:") + Environment.NewLine;
                        for (int i = 0; i < numGroups; i++)
                        {
                            txtUitvoer.Text += ($"Group {i + 1}: {string.Join(", ", groups[i])}" + Environment.NewLine);
                        }

                    }
                }
                else if (rbtPeople.Checked == true)
                {

                    int numPeople = Convert.ToInt32(nudPeople.Value);
                    if (numPeople <= 0)
                    {
                        txtUitvoer.Text = "Please enter a valid number of groups greater than 0.";
                    }
                    else
                    {
                        // Shuffle the names array randomly
                        Random random = new Random();
                        names = names.OrderBy(x => random.Next()).ToArray();

                        // Calculate the number of groups and the remaining names
                        int numGroups = Convert.ToInt32(Math.Ceiling(names.Length / Convert.ToDouble(numPeople)));
                        int namesPerGroup = names.Length / numGroups;
                        int remainingNames = names.Length % numGroups;

                        // Divide the shuffled names into groups
                        string[][] groups = new string[numGroups][];
                        int currentIndex = 0;

                        for (int i = 0; i < numGroups; i++)
                        {
                            // Determine the size of the current group
                            int currentGroupSize = namesPerGroup + (i < remainingNames ? 1 : 0);

                            // Take a portion of names for each group
                            groups[i] = names.Skip(currentIndex).Take(currentGroupSize).ToArray();

                            // Update the current index for the next iteration
                            currentIndex += currentGroupSize;
                        }

                        // Display the groups
                        txtUitvoer.Text += ("\nGroups:") + Environment.NewLine;
                        for (int i = 0; i < numGroups; i++)
                        {
                            txtUitvoer.Text += ($"Group {i + 1}: {string.Join(", ", groups[i])}" + Environment.NewLine);
                        }
                    }
                }

            }
        }

        private void frmGroups_Load(object sender, EventArgs e)
        {
            // Adjust the folder path on your desktop
            string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "klassen");

            // Display the available .txt files in the folder
            string[] files = Directory.GetFiles(folderPath, "*.txt").Select(Path.GetFileName).ToArray();
            foreach (string file in files)
            {
                lblTxtNamen.Text += file + Environment.NewLine;
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // hide form 1
            this.Hide();
            // make a instance of form Info
            Info f2 = new Info();
            // show form Info
            f2.ShowDialog(); // it gonna freeze the execution of click event.
            // dispose form Info instance
            f2 = null;
            // show form1 again
            this.Show();
        }
    }
}
