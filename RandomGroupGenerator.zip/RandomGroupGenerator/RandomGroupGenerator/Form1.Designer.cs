﻿namespace RandomGroupGenerator
{
    partial class frmGroups
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGroups));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nudNumber = new System.Windows.Forms.NumericUpDown();
            this.nudPeople = new System.Windows.Forms.NumericUpDown();
            this.rbtNumber = new System.Windows.Forms.RadioButton();
            this.rbtPeople = new System.Windows.Forms.RadioButton();
            this.lblOptions = new System.Windows.Forms.Label();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.txtUitvoer = new System.Windows.Forms.TextBox();
            this.lblTxtNamen = new System.Windows.Forms.Label();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPeople)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(35, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Names";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(424, 201);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Groups";
            // 
            // nudNumber
            // 
            this.nudNumber.Location = new System.Drawing.Point(548, 66);
            this.nudNumber.Name = "nudNumber";
            this.nudNumber.Size = new System.Drawing.Size(120, 20);
            this.nudNumber.TabIndex = 7;
            // 
            // nudPeople
            // 
            this.nudPeople.Location = new System.Drawing.Point(548, 93);
            this.nudPeople.Name = "nudPeople";
            this.nudPeople.Size = new System.Drawing.Size(120, 20);
            this.nudPeople.TabIndex = 8;
            // 
            // rbtNumber
            // 
            this.rbtNumber.AutoSize = true;
            this.rbtNumber.Checked = true;
            this.rbtNumber.Location = new System.Drawing.Point(427, 69);
            this.rbtNumber.Name = "rbtNumber";
            this.rbtNumber.Size = new System.Drawing.Size(114, 17);
            this.rbtNumber.TabIndex = 9;
            this.rbtNumber.TabStop = true;
            this.rbtNumber.Text = "Number of Groups:";
            this.rbtNumber.UseVisualStyleBackColor = true;
            // 
            // rbtPeople
            // 
            this.rbtPeople.AutoSize = true;
            this.rbtPeople.Location = new System.Drawing.Point(427, 95);
            this.rbtPeople.Name = "rbtPeople";
            this.rbtPeople.Size = new System.Drawing.Size(111, 17);
            this.rbtPeople.TabIndex = 10;
            this.rbtPeople.Text = "People per Group:";
            this.rbtPeople.UseVisualStyleBackColor = true;
            // 
            // lblOptions
            // 
            this.lblOptions.AutoSize = true;
            this.lblOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOptions.Location = new System.Drawing.Point(427, 27);
            this.lblOptions.Name = "lblOptions";
            this.lblOptions.Size = new System.Drawing.Size(64, 17);
            this.lblOptions.TabIndex = 11;
            this.lblOptions.Text = "Options";
            // 
            // btnGenerate
            // 
            this.btnGenerate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerate.Location = new System.Drawing.Point(427, 139);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(241, 44);
            this.btnGenerate.TabIndex = 12;
            this.btnGenerate.Text = "Generate!";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // txtUitvoer
            // 
            this.txtUitvoer.Location = new System.Drawing.Point(427, 239);
            this.txtUitvoer.Multiline = true;
            this.txtUitvoer.Name = "txtUitvoer";
            this.txtUitvoer.Size = new System.Drawing.Size(241, 121);
            this.txtUitvoer.TabIndex = 13;
            // 
            // lblTxtNamen
            // 
            this.lblTxtNamen.AutoSize = true;
            this.lblTxtNamen.Location = new System.Drawing.Point(38, 72);
            this.lblTxtNamen.Name = "lblTxtNamen";
            this.lblTxtNamen.Size = new System.Drawing.Size(0, 13);
            this.lblTxtNamen.TabIndex = 14;
            // 
            // txtFileName
            // 
            this.txtFileName.Location = new System.Drawing.Point(41, 270);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(158, 20);
            this.txtFileName.TabIndex = 15;
            this.txtFileName.Text = ".txt";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Put the file you want to use here";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(757, 414);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // frmGroups
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFileName);
            this.Controls.Add(this.lblTxtNamen);
            this.Controls.Add(this.txtUitvoer);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.lblOptions);
            this.Controls.Add(this.rbtPeople);
            this.Controls.Add(this.rbtNumber);
            this.Controls.Add(this.nudPeople);
            this.Controls.Add(this.nudNumber);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "frmGroups";
            this.Text = "RandomGroupGenerator";
            this.Load += new System.EventHandler(this.frmGroups_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPeople)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudNumber;
        private System.Windows.Forms.NumericUpDown nudPeople;
        private System.Windows.Forms.RadioButton rbtNumber;
        private System.Windows.Forms.RadioButton rbtPeople;
        private System.Windows.Forms.Label lblOptions;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.TextBox txtUitvoer;
        private System.Windows.Forms.Label lblTxtNamen;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

